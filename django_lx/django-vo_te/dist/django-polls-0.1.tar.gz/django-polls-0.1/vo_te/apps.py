from django.apps import AppConfig


class VoTeConfig(AppConfig):
    name = 'vo_te'
